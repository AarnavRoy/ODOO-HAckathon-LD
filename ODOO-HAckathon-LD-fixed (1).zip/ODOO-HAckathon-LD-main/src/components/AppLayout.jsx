import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { LogOut, Home, Plane, User, Globe, ShieldCheck, Map, Plus, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AppLayout({ children, title }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  const isAdminRoute = location.pathname.startsWith('/admin');
  
  let navLinks = [];
  if (isAdminRoute && user?.role === 'ROLE_ADMIN') {
    navLinks = [
      { to: '/admin', label: 'Admin Portal', icon: ShieldCheck, match: (p) => p.startsWith('/admin') }
    ];
  } else {
    navLinks = [
      { to: '/', label: 'Home', icon: Home, match: (p) => p === '/' },
      { to: '/trips', label: 'My Trips', icon: Map, match: (p) => p.startsWith('/trips') && !p.includes('/new') },
      { to: '/trips/new', label: 'Plan Trip', icon: Plus, match: (p) => p === '/trips/new' },
      { to: '/ai-planner', label: 'AI Planner', icon: Sparkles, match: (p) => p === '/ai-planner' },
      { to: '/profile', label: 'Profile', icon: User, match: (p) => p === '/profile' },
    ];
  }
  
  const layoutClasses = "min-h-[100dvh] bg-[#0B0F19] flex flex-col font-sans text-slate-200";

  const headerClasses = "flex flex-wrap justify-between items-center bg-[#131A2A]/80 backdrop-blur-md border border-[#1F2937] p-3 rounded-3xl shadow-sm gap-3";

  const logoClasses = "flex-shrink-0 flex items-center text-2xl font-extrabold tracking-tight text-white hover:scale-105 transition-transform";

  const globeIconClasses = "w-7 h-7 mr-2 text-white";

  return (
    <div className={layoutClasses}>
      {/* Navbar */}
      <header className="sticky top-4 z-50 px-4 sm:px-6 lg:px-8 mt-4">
        <div className="max-w-7xl mx-auto">
          <div className={headerClasses}>
            {/* Logo */}
            <Link to="/" className={logoClasses}>
              <Globe className={globeIconClasses} />
              GlobeTrotter<span className="text-amber-400">.</span>
            </Link>
            
            {/* Pill Navigation */}
            <nav className="flex space-x-1 items-center bg-[#0B0F19] border border-[#1F2937] rounded-full px-2 py-1.5 shadow-md overflow-x-auto max-w-full">
              {navLinks.map(link => {
                const Icon = link.icon;
                const active = link.match(location.pathname);
                return (
                  <Link 
                    key={link.to} 
                    to={link.to} 
                    className={`px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all duration-200 whitespace-nowrap focus-visible:ring focus-visible:ring-amber-400 ${
                      active ? 'bg-[#EAB308] text-slate-950 shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-[#131A2A]/10'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{link.label}</span>
                  </Link>
                );
              })}
            </nav>

            {/* Logout */}
            <button 
              onClick={handleLogout} 
              className="flex items-center text-xs sm:text-sm font-semibold transition-colors active:scale-95 px-4 py-2 rounded-full cursor-pointer text-slate-300 hover:text-[#F87171] hover:bg-[#131A2A]/5 focus-visible:ring focus-visible:ring-amber-400"
            >
              <LogOut className="w-4 h-4 mr-1.5" /> Logout
            </button>
          </div>
        </div>
      </header>

      {/* Page content with route transitions */}
      <AnimatePresence mode="wait">
        <motion.main
          key={location.pathname}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-10"
        >
          {title && (
            <motion.h1
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.08, duration: 0.35 }}
              className="text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-8"
            >
              {title}
            </motion.h1>
          )}
          {children}
        </motion.main>
      </AnimatePresence>
    </div>
  );
}


